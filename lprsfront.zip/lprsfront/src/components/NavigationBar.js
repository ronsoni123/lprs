import React from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { store } from "./store";
import Edit from "./Edit";

var buttonStyle = {
  backgroundColor: "#F3E367",
  padding: "0em 2em 0em",
  border: "0px solid white",
  borderRadius: ".4em",
  lineHeight: "2.2em",
  verticalAlign: "middle",
  textAlign: "center",
  transition: "opacity .25s,color 275ms",
  transitionTimingFunction: "cubic-bezier(.4,.25,.3,1)"
};

var buttonStyle2 = {
  backgroundColor: "rgba(127,134,136,1)",
  padding: "0em 2em 0em",
  border: "1px solid ",
  borderRadius: ".4em",
  lineHeight: "2.2em",
  verticalAlign: "middle",
  textAlign: "center",
  transition: "opacity .25s,color 275ms",
  transitionTimingFunction: "cubic-bezier(.4,.25,.3,1)"
};

class NavigationBar extends React.Component {
  
  guestLinks = (
    <React.Fragment>
      <li className="nav-item">
        <button style={buttonStyle2} className="btn btn-sm btn-outline-light ">
          <Link className="nav-link" to="/login" >
            <span className="text-light">
              <strong>SIGN IN</strong>
            </span>
          </Link>
        </button>
        &nbsp;
      </li>
      <li className="nav-item">
        <button style={buttonStyle} className="btn btn-sm  btn-outline-dark">
          <Link className="nav-link" to="/signup"  >
            <span className="text-dark">
              <strong>SIGN UP</strong>
            </span>
          </Link>
        </button>
      </li>
    </React.Fragment>
  );
  
  componentWillMount = () => {
    const action = {
      type: "Login",
      emailId: localStorage.getItem("email")
        ? localStorage.getItem("email")
        : "",
      firstName: localStorage.getItem("firstName")
        ? localStorage.getItem("firstName")
        : "",
      lastName: localStorage.getItem("lastName")
        ? localStorage.getItem("lastName")
        : "",
      password: localStorage.getItem("password")
        ? localStorage.getItem("password")
        : "",
      customerId: localStorage.getItem("customerId")
        ? localStorage.getItem("customerId")
        : ""
    };
    store.dispatch(action);
  };

  render() {
    return (
      <React.Fragment>
        <nav
          className="navbar navbar-expand-sm navbar-dark "
        >
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#collapsibleNavbar"
          >
            <span className="navbar-toggler-icon" />
          </button>
          <div className="collapse navbar-collapse" id="collapsibleNavbar">
            {this.props.emailId.length > 0 ? (
              <React.Fragment>
                <Link className="text-white navbar-brand" to="/">
                  <span style={{ color: "yellow" }}>
                    <i class="fas fa-car" style={{ fontSize: "40px" }} />
                    &nbsp;
                  </span>
                </Link>
                <Link className="navbar-brand text-white " to="/home">
                  <span style={{ color: "white", fontFamily: "arial" }}>
                    Home
                  </span>
                </Link>

                <Edit />
              </React.Fragment>
            ) : (
              <Link className="nav-item active navbar-brand" to="/" >
                <span style={{ color: "yellow" }}>
                  <i className="fas fa-car" style={{ fontSize: "40px" }} />
                  &nbsp;
                </span>
                <span
                  className="text-light"
                  style={{ fontSize: "30px", fontFamily: "Bad Script" }}
                >
                  LPRS
                </span>
              </Link>
            )}
          </div>

          <ul className="navbar-nav ml-auto">
            {this.props.emailId.length > 0 ? (
              <React.Fragment>
                <li className="nav-item">
                  <Link className="nav-link text-white">
                    <h5 style={{ color: "white", fontFamily: "arial" }}>
                      <i class="fas fa-user" style={{ color: "yellow" }} />
                      &nbsp; Hello, {this.props.firstName}
                    </h5>
                  </Link>
                </li>
                &nbsp;&nbsp;&nbsp;
                <li>
                  <Link className="navbar-brand text-white" to="/logout">
                    <span style={{ color: "yellow" }}>
                      Sign Out &nbsp;
                      <i class="fas fa-sign-out-alt" />
                    </span>
                  </Link>
                </li>
              </React.Fragment>
            ) : (
              this.guestLinks
            )}
          </ul>
        </nav>
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    emailId: state.emailId,
    firstName: state.firstName,
    lastName: state.lastName,
    password: state.password,
    customerId:state.customerId
  };
}
NavigationBar = connect(mapStateToProps)(NavigationBar);

export default NavigationBar;
