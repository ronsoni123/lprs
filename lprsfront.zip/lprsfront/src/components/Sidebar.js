import React from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { store } from "./store";

var styles = {
  bmBurgerButton: {
    position: "fixed",
    width: "30px",
    height: "22px",
    left: "20px",
    top: "30px"
  },
  bmBurgerBars: {
    background: "white"
  },
  bmBurgerBarsHover: {
    background: "#292b2c"
  },
  bmCrossButton: {
    height: "20px",
    height: "100%"
  },
  bmMenu: {
    background: "#373a47",
    padding: "2em 1.5em 0",
    fontSize: "1.15em",
    padding: "1em 1.5em 0",
    fontSize: "1.15em"
  },
  bmMorphShape: {
    fill: "#373a47",
    display: "inline-block"
  },
  bmOverlay: {
    background: "#292b2c"
  }
};

class SideBar extends React.Component {
  componentWillMount = () => {
    const action = {
      type: "Login",
      emailId: localStorage.getItem("email")
        ? localStorage.getItem("email")
        : "",
      firstName: localStorage.getItem("firstName")
        ? localStorage.getItem("firstName")
        : "",
      lastName: localStorage.getItem("lastName")
        ? localStorage.getItem("lastName")
        : "",
      password: localStorage.getItem("password")
        ? localStorage.getItem("password")
        : "",
      customerId: localStorage.getItem("customerId")
        ? localStorage.getItem("customerId")
        : ""
    };
    store.dispatch(action);
  };

  render() {
    return (
      <div id="outer-container" className="fill">
        <ul className="navbar-nav">
          {console.log(this.props)}
          {this.props.emailId.length > 0 ? (
            <Menu
              pageWrapId={"page-wrap"}
              outerContainerId={"outer-container"}
              noOverlay
              disableAutoFocus
              styles={styles}
            >
              <br />
              <li>
                <Link className="text-white navbar-brand" to="/">
                  LPRS Main Page
                </Link>
              </li>
              <li>
                <Link className="navbar-brand text-white " to="/home">
                  Home
                </Link>
              </li>
              <li>
                <Link className="navbar-brand text-white" to="/contact">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link className="navbar-brand text-white" to="/logout">
                  Logout
                </Link>
              </li>
            </Menu>
          ) : null}
        </ul>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    emailId: state.emailId,
    firstName: state.firstName,
    lastName: state.lastName,
    password: state.password,
    customerId:state.customerId
  };
}
Sidebar = connect(mapStateToProps)(Sidebar);
export default Sidebar;
