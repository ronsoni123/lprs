import React, { Component } from "react";
import axios from "axios";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";
import IconButton from "@material-ui/core/IconButton";
import InputAdornment from "@material-ui/core/InputAdornment";
import TextField from "@material-ui/core/TextField";
import { Redirect } from "react-router-dom";
import {store} from "./store";
import {connect} from "react-redux"
var jwt = require('jsonwebtoken');

class Login extends Component {
  constructor() {
    super();
    this.state = {
      form: {
        emailAddress: "",
        password: ""
      },
      formErrorMessage: {
        emailAddress: "",
        password: ""
      },
      formValid: {
        emailAddress: false,
        password: false,
        buttonActive: false
      },
      successMessage: "",
      errorMessage: "",
      showPassword: false
    };
  }

  componentWillMount=()=>{
    const action={
      type:"Login",
      emailId:localStorage.getItem("email")?localStorage.getItem("email"):"",
      firstName:localStorage.getItem("firstName")?localStorage.getItem("firstName"):"",
      lastName:localStorage.getItem("lastName")?localStorage.getItem("lastName"):"",
      password:localStorage.getItem("password")?localStorage.getItem("password"):"",
      customerId:localStorage.getItem("customerId")?localStorage.getItem("customerId"):""
    }
    store.dispatch(action);
  }


  loginUser = () => {
    var loginObj = {
      email: this.state.form.emailAddress,
      password: this.state.form.password
    };

    var action={
      type:"Login",
    }

    axios
      .post("http://localhost:2500/login", loginObj)
      .then(response => {
        this.setState({
          successMessage: response.data.message,
          errorMessage: ""
        });
        var decodedObj = jwt.verify(response.data.message, 'shhhhh');

        action.emailId=decodedObj.email
        action.firstName=decodedObj.firstName
        action.lastName=decodedObj.lastName
        action.password=decodedObj.password
        action.customerId=decodedObj.customerId
 

        localStorage.setItem("email",decodedObj.email);
        localStorage.setItem("firstName",decodedObj.firstName);
        localStorage.setItem("lastName",decodedObj.lastName);
        localStorage.setItem("password",decodedObj.password);
        localStorage.setItem("customerId",response.data.message);
        store.dispatch(action);
      })
      .catch(err => {
        this.setState({
          errorMessage: err.response.data.message,
          successMessage: ""
        });
      });
  };

  handleChange = event => {
    var value = event.target.value;
    var fieldname = event.target.name;
    var form = this.state.form;

    form[fieldname] = value;

    this.setState({ form: form });
    this.validateField(fieldname, value);
  };

  validateField = (fieldName, value) => {
    var formErrorMessage = this.state.formErrorMessage;
    var formValid = this.state.formValid;

    if (fieldName === "emailAddress") {
      if (value === "") {
        formErrorMessage.emailAddress = "field required";
        formValid.emailAddress = false;
      } else {
        formErrorMessage.emailAddress = "";
        formValid.emailAddress = true;
      }
      this.setState({ formErrorMessage: formErrorMessage });
      this.setState({ formValid: formValid });
    } else if (fieldName === "password") {
      if (value === "") {
        formErrorMessage.password = "field required";
        formValid.password = false;
      } else {
        formErrorMessage.password = "";
        formValid.password = true;
      }
      this.setState({ formErrorMessage: formErrorMessage });
      this.setState({ formValid: formValid });
    }
    formValid.buttonActive = formValid.emailAddress && formValid.password;
    this.setState({ formValid: formValid });
  };

  handleClickShowPassword = () => {
    this.setState(state => ({ showPassword: !state.showPassword }));
  };

  handleSubmit = event => {
    event.preventDefault();
    this.loginUser();
  };

  render() {
    if (this.state.successMessage) {
      return (
        <React.Fragment>                           
           <Redirect to={"/lprs"} push
           />          
        </React.Fragment>
      );
    }
    if(this.props.emailId.length>0){
      console.log("going to home")
      return (<Redirect to="/lprs" push/>)
    }

    return (
      <React.Fragment>
        <div className="Login">
          <div className="container-fluid row">
            <div className="col-md-6 offset-md-3">
              <br />
              {/* <div className="card" style={{backgroundColor: "inherit", border:"0 0 0 0"}}> */}
              <div className="card" style={{borderRadius:"20px"}}>
                <div className="card-header">
                  <h3 className="text-center text-dark">
                    <strong><i class="fas fa-unlock"></i> Login</strong>
                  </h3>
                </div>
                <div className="card-body">
                  <form onSubmit={this.handleSubmit}>
                    <div className="form-group row">
                      <label className="col-sm-1">
                        <span style={{fontSize: "25px"}}><strong><i class="fas fa-envelope"></i></strong></span>
                      </label>
                      <div className="col-sm-11">
                      <TextField
                        className="form-control"
                        type="email"
                        name="emailAddress"
                        onChange={this.handleChange}
                        placeholder="Email"
                      />
                        <span className="text-danger" name="emailAddressError">
                        {this.state.formErrorMessage.emailAddress}
                      </span>
                      </div>                    
                    </div>

                    <div className="form-group row">
                      <label className="col-sm-1"><span style={{fontSize: "25px"}}><i class="fas fa-unlock"></i></span>
                      </label>
                      <div className="col-sm-11">
                      <TextField
                        id="filled-adornment-password"
                        className="form-control"
                        type={this.state.showPassword ? "text" : "password"}
                        name="password"
                        placeholder="Password"
                        value={this.state.password}
                        onChange={this.handleChange}
                        InputProps={{
                          endAdornment: (
                            <InputAdornment position="end">
                              <IconButton
                                aria-label="Toggle password visibility"
                                onClick={this.handleClickShowPassword}
                              >
                                {this.state.showPassword ? (
                                  <VisibilityOff />
                                ) : (
                                  <Visibility />
                                )}
                              </IconButton>
                            </InputAdornment>
                          )
                        }}
                      />
                      <span className="text-danger" name="passwordError">
                      {this.state.formErrorMessage.password}
                    </span>
                    </div>
                    </div>

                    <button
                      type="submit"
                      className="btn form-control "
                      disabled={!this.state.formValid.buttonActive}
                      style={{backgroundColor:"#F3E367"}}
                      name="login"
                    >
                      <strong>Login</strong>
                    </button>
                    <br />
                    <span className="text-danger" name="errorMessage">
                      {this.state.errorMessage}
                    </span>
                    <br />
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
function mapStateToProps(state) {
  return {
    emailId: state.emailId,
    firstName: state.firstName,
    lastName: state.lastName,
    password: state.password,
    customerId:state.customerId
  };
}
Login = connect(mapStateToProps)(Login);
export default Login;
