import { createStore } from "redux";
// import { combineReducers } from "redux";
// import {sessionReducer,sessionService} from 'redux-react-session';
const initialState = {
  emailId: "",
  firstName: "",
  lastName: "",
  password: "",
  customerId:""
};
const reducer = function(state = initialState, action) {
  var stateCopy = Object.assign({}, state);
  switch (action.type) {
    case "Login":
      stateCopy.emailId = action.emailId;
      stateCopy.firstName = action.firstName;
      stateCopy.lastName = action.lastName;
      stateCopy.password = action.password;
      stateCopy.customerId = action.customerId;
      return stateCopy;
    default:
      return state;
  }
};
export const store = createStore(reducer);
