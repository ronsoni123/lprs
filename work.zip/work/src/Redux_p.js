import { createStore } from 'redux';
import React from "react";
import {Provider,connect} from 'react-redux';


const initialState= {
    price:0,
    qty:0,
    valid:false
}

function changePrice(state=initialState,action){
    var stateCopy=Object.assign({},state);
    switch(action.type){        
        case 'INCREMENT':           
            stateCopy.qty=stateCopy.qty+action.qty;
            stateCopy.price+= action.qty*action.price;
           
            stateCopy.valid=true
            return stateCopy;
        case 'DECREMENT':
            if(stateCopy.qty>1){
                stateCopy.qty=stateCopy.qty-action.qty;            
                stateCopy.price-=action.qty*action.price;

                stateCopy.valid=true
                return stateCopy;
            }
            else{
                stateCopy.qty=stateCopy.qty-action.qty;            
                stateCopy.price=stateCopy.qty*action.price;
                stateCopy.valid=false
                return stateCopy;
            }            
        default:
            return state
    }
}
export const store= createStore(changePrice);
 
class Bar extends React.Component{
    constructor(){
        super();
        this.state={
            qty:0,
            price:0,
            valid:false,
            counter:0,
            counterValid:false
           
        }
    }

    incrementPrice=(price)=>{
        
        var action={
            type:'INCREMENT',
            price:price ,
            qty:1           
        }
        this.setState({counter:this.state.counter+1,counterValid:true})
        store.dispatch(action);
      
    }

    decrementPrice=(price)=>{
       
        var action={
            type:'DECREMENT',
            price:price,
            qty:1            
        }
        if(this.state.counter>1)        
            this.setState({counter:this.state.counter-1,counterValid:true});
        else
            this.setState({counter:this.state.counter-1,counterValid:false});
        store.dispatch(action);
     
    }

    componentDidMount=()=>{
        store.subscribe(()=>{
            var globalStore= store.getState();
            this.setState({qty:globalStore.qty,price:globalStore.price,
                valid:globalStore.valid})
        })
    }

    render(){
        return(
                <div>     
                    <button className="btn btn-danger form-control" type="button" disabled={!this.state.counterValid}
                    onClick={()=>this.decrementPrice(this.props.price)}                    
                    >-</button>  

                    <input type="text" className="form-control" value={this.state.counter}/>

                    <button className="btn btn-success form-control" type="button" 
                    onClick={()=>this.incrementPrice(this.props.price)                    
                    }>
                    +</button>
                    
                </div>

        )
    }
}

export default Bar;