import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
// import Card from './Book_card';
import Routing from './Routing'
// import Redux from './Redux_p'
// import Home from './Class_redux'

ReactDOM.render(<div>
    <Routing/>
    {/* <Home/> */}
</div>, document.getElementById('root'));

