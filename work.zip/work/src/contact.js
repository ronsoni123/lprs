import React from 'react';
class Contact extends React.Component{

    render() {
        return (
            <div>
                <h1 className="text-primary text-center">We are available 24 hrs from Monday to Sunday</h1>
                <h6 className="text-primary text-center">Email us at <i>abc@gmail.com</i></h6>
            </div>
        )
    }
}
export default Contact;