import React from "react";
import axios from 'axios';
import Bar from './Redux_p'
import { Cart } from './cart.js'
import {Redirect} from 'react-router-dom';
class Book extends React.Component {
  constructor() {
    super();
    this.state = {
      arrBook: []
    }


    axios
      .get("http://localhost:3500/book")
      .then(response => {
        var bookArr = response.data;
        this.setState({ arrBook: bookArr });
      })

  }

  render() {
    return (
      <React.Fragment>
        
       <div className="container-fluid">
          <div className="row">
          <div className="col-md-8">
            <h2 className="text-center text-primary">Featured Books</h2>
          </div>
          </div>
          <div className="row">
            <div className="col-md-8">
              <div className="container-fluid">
                  <div className="row">
                  {this.state.arrBook.map(book => {
            return (
              <CreateCard emp={book} />
            )
          })}
                  </div>
              </div>
            </div>
            
          </div>
          </div>
       
      </React.Fragment>
    )
  }
}

class CreateCard extends React.Component {
  constructor() {
    super();
    this.state = {
      title: null,
      edit:false,
      delete:true
    }
  }
  render() {
    var details = null;
    var price = null;
    var author = null
    var redirect=null;
    if (this.state.title === this.props.emp.title) {
      details = "Details: " + this.props.emp.details;
      price = "Price: " + this.props.emp.price;
      author = "Author: " + this.props.emp.author;
    }

    if(this.state.edit==true){
      var url="/edit/"+this.props.emp.id;
      redirect=<Redirect to={url} push/>
    }
    return (
      <div className="col-md-3">
        <div className="card" >
          <img src={this.props.emp.img} className="img-card-top" alt="Image not found" />
          <div className="card-body">
            <div className="card-text">
              <span>BookId: {this.props.emp.id}</span><br />
              <span>Title: {this.props.emp.title}</span><br />
              <span>Genre: {this.props.emp.genre}</span><br />
            </div>
            <div>
              {author}
            </div>
            <div>
              {details}
            </div>
            <div>
              {price}
            </div>
            <br />
            <div>
              <button type="button" className="btn btn-success"
                onClick={() => { this.setState({ title: this.props.emp.title }) }}>
                View</button>

              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  
            <button type="button" className="btn btn-danger"
                onClick={() => { this.setState({ title: null }) }}>
                Hide</button>
              <br /><br />
              <button type="button" className="btn btn-danger"
                onClick={() => { this.setState({ edit: true }) }}>
                Edit</button>
              <br /><br />
              {redirect}
              <Bar price={this.props.emp.price} />

            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default Book;
