import React from "react";
import {Provider,connect} from 'react-redux';

export class Cart extends React.Component{
    
    render(){
        var css={position:"fixed",border:"grey 2px solid",padding:"20px",
            "box-shadow":"10px 10px 5px grey","margin-top":"380px","margin-left":"990px",
            };
        return(
            // style={css}
            <div  >
                <h3>
                <span >This is Cart Price:{this.props.price}</span>
                <br/>
                <br/>
                <span >This is Cart Item:{this.props.qty}</span>
                </h3>
            </div>          
        )
    }
}
function mapStateToProps(state){
    return {
        qty:state.qty,
        price:state.price
    }
}
Cart=connect(mapStateToProps)(Cart)

