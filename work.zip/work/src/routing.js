import React from 'react';
import {BrowserRouter, Link, Route, Redirect,Switch } from 'react-router-dom';
// import Books from './Book_card';
import Addbook from './form';
// import Cart from './Cart'

class Contact extends React.Component{

    render() {
        return (
            <div>
                <h1 className="text-primary">Contact us at below conatct and address for conatcting us</h1>
            </div>
        )
    }
}

class Routing extends React.Component {  
  
render() {
        return (    
            <div>    
                <BrowserRouter>    
                    <nav className="navbar navbar-expand-md bg-dark navbar-dark">    
                        <button className="navbar-toggler" type="button" data-toggle="collapse" 
                        data-target="#navbar-collapsed">        
                            <span className="navbar-toggler-icon"></span>    
                        </button>    
                        <div className="collapse navbar-collapse" id="navbar-collapsed">    
                            <Link to="/" className="navbar-brand">Learning Portal
                            </Link>    
                        <ul className="navbar-nav">    
                            <li className="navbar-item ">    
                                <Link to="/card" className="navbar-item nav-link">View All Books
                                </Link>    
                            </li>    
                            <li className="navbar-item ">    
                                <Link to="/addBook" className="nav-link navbar-item">Add a Book
                                </Link>    
                            </li>    
                            <li className="navbar-item">    
                                <Link className="navbar-item nav-link" to="/contact">Contact Us
                                </Link>
                            </li>    
                        </ul> 
                        <ul class="navbar-nav ml-auto">
                            <li className="navbar-item ">    
                                <Link to="/cart" className="nav-link navbar-item">Cart
                                </Link>    
                            </li> 
                        </ul>   
                        </div>    
                    </nav>    
                    <React.Fragment>    
                        <Switch>    
                            <Route exact path="/" render={()=><Redirect to="/card" push/>}/>    
                            {/* <Route path="/card" component={Books}/>     */}
                            <Route path="/addBook" component={Addbook}/>    
                            <Route path="/contact" component={Contact}/>    
                            {/* <Route path="/cart" component={Cart}/>     */}
                        </Switch>    
                    </React.Fragment>    
                </BrowserRouter>    
            </div>    
        );    
    }    
}
    
    

  export default Routing;

