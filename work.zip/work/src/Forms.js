import React from "react";
import axios from 'axios';

class Form extends React.Component {
    constructor() {
        super();
        this.state = {
            author: '',
            title: '',
            genre: '',
            details:'',
            img:"book1.jpg",
            price:'',

            formErrors:{
                titleErr: '',
                genreErr: '',
                authorErr:'',
                priceErr:''
            },

            fieldValidity: {
                title: false,
                author: false,
                genre:false,
                price:false
            },

            formValid: false,
            successMessage: '',
            id:null
        };
    }

    validateTitle = (e) => {
        const title = e.target.value;
        var formErrors = this.state.formErrors;
        var fieldValidity = this.state.fieldValidity;

        if (title.length < 4) {
            formErrors.titleErr = "Title must be 4 character long";
            fieldValidity.title = false;
        }
        else {
            formErrors.titleErr = "";
            fieldValidity.title = true;
        }
        this.setState({ title: title});
        this.setState({ fieldValidity: fieldValidity })
        this.setState({ formValid: fieldValidity.title && fieldValidity.author  && fieldValidity.genre
            && fieldValidity.price})
    }

    validateAuthor = (e) => {
        const author = e.target.value;
        var formErrors = this.state.formErrors;
        var fieldValidity = this.state.fieldValidity;
        if (author.length<3) {
            formErrors.authorErr = "Author must be 3 character long"
            fieldValidity.author = false;
        }
        else {
            formErrors.authorErr = ""
            fieldValidity.author = true;
        }
        this.setState({ author:author});
        this.setState({ formErrors: formErrors });
        this.setState({ formValid: fieldValidity.author && fieldValidity.title  && fieldValidity.genre
            && fieldValidity.price})
    }

    validateGenre = (e) => {
        var genre = e.target.value;
        
        var formErrors = this.state.formErrors;
        var fieldValidity = this.state.fieldValidity;

        if (genre==0) {
            
            formErrors.genreErr = "Genre must be selected"
            fieldValidity.genre = false;
        }
        else {
            formErrors.genreErr = ""
            fieldValidity.genre = true;
        }
        this.setState({ genre:genre});
        this.setState({ formErrors: formErrors });
        this.setState({ formValid: fieldValidity.author && fieldValidity.title && fieldValidity.genre 
            && fieldValidity.price })
    }
    
    validateDetails = (e) => {
        const details = e.target.value;
        if (details) {
            this.setState({details:details});
        }
        else{
            this.setState({details:""});
        }
    }

    validatePrice = (e) => {
        const price = e.target.value;
        var formErrors = this.state.formErrors;
        var fieldValidity = this.state.fieldValidity;

        if (price<0) {
            formErrors.priceErr = "Price must be greater than 0";
            fieldValidity.price = false;
        }
        else {
            formErrors.priceErr = "";
            fieldValidity.price = true;
        }
        this.setState({ price:price});
        this.setState({ fieldValidity: fieldValidity })
        this.setState({ formValid: fieldValidity.title && fieldValidity.author  && fieldValidity.genre
        && fieldValidity.price})
    }

    Addbook = (e) => {
        e.preventDefault();
        
        if (this.state.formValid) {
            var formJSON = {
                title: this.state.title,
                author: this.state.author,
                genre: this.state.genre ,
                details:this.state.details,
                img:this.state.img,
                price:this.state.price               
            }
            // this.setState({ successMessage:"Successfully added" });
            // JSON.stringify(formJSON
            axios
            .post("http://localhost:3500/book",formJSON)
            .then(r=>{
                this.setState({ successMessage:"Successfully added" });
            })
            .catch(err=>{
                console.log(err);
            })
        }
    }
    render() {
        return (
            <div style={{width:500, margin:'0px auto'}}>
            <div>
                <h1 className="text-primary text-center">Add A Book</h1>
            </div>
                <form >                    
                    <div className="form-group">
                        <label className="text-info">Title:</label>
                        <input className="form-control" onChange={this.validateTitle} 
                        value={this.state.title} type="text"/>                    
                        <span className="text-danger">{this.state.formErrors.titleErr}</span>
                    </div>
                    {/* <br/> */}

                    <div className="form-group">
                        <label className="text-info">Details:</label>
                        <input className="form-control" onChange={this.validateDetails} 
                        value={this.state.details} type="text"/>
                    </div>
                    {/* <br/> */}

                    <div className="form-group">
                        <label className="text-info">Author:</label>
                        <input className="form-control" onChange={this.validateAuthor} 
                        value={this.state.author} />                    
                        <span className="text-danger">{this.state.formErrors.authorErr}</span>
                    </div>
                    {/* <br/> */}

                     <div className="form-group">
                        <label className="text-info">Price:</label>
                        <input className="form-control" onChange={this.validatePrice} 
                        value={this.state.price} type="number"/>                    
                        <span className="text-danger">{this.state.formErrors.priceErr}</span>
                    </div>
                    {/* <br/> */}

                    <div className="form-group">
                        <label className="text-info">Genre:</label>
                        <select onChange={this.validateGenre} className="form-control" >
                            <option value="0" >--Select--</option>
                            <option value="Science Fiction">Science Fiction</option>
                            <option value="Drama">Drama</option>
                            <option value="Thriller">Thriller</option>
                        </select>                    
                        <span className="text-danger">
                            {this.state.formErrors.genreErr}
                        </span>
                    </div>
                    
                    <button type="button" onClick={this.Addbook} className="btn btn-success form-control" 
                    disabled={!this.state.formValid}>Add Book
                    </button>
                    <br/>
                        <span className="text-success">{this.state.successMessage}</span>
                    <br/>
                </form>
            </div>
        );
    }
}
export default Form;
