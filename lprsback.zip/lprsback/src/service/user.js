var model = require('../model/user');
var Validator = require('../utilities/validator');

var lprsService = {};

lprsService.signupUser = (userObj) => {    
    Validator.validateFirstName(userObj.firstName);
    Validator.validateLastName(userObj.lastName);
    Validator.validateEmail(userObj.email);
    Validator.validatePassword(userObj.password);

    return model.signupUser(userObj).then(cust=>{        
        if(cust==null){
            let err = new Error("Signup Failed");
            err.status = 400;
            throw err;
        }
        else{
            return cust;
        }
    })
}

lprsService.editUser = (userObj) => {    
    Validator.validateFirstName(userObj.firstName);
    Validator.validateLastName(userObj.lastName);
    Validator.validateEmail(userObj.email);
    Validator.validatePassword(userObj.password);

    return model.editUser(userObj).then(obj=>{        
        if(obj==null){
            let err = new Error("Fail to update");
            err.status = 400;
            throw err;
        }
        else{
            return obj;
        }
    })
}


lprsService.loginUser=(loginObj)=>{
    Validator.validateEmail(loginObj.email);
    Validator.validatePassword(loginObj.password);
    return model.login(loginObj).then(cust=>{              
        if(cust){
            return cust;
        }
        else{
            let err = new Error("Email/Password incorrect");
            err.status = 401;
            throw err;
        }
    })
}

lprsService.findCorrectPlate=(predictedPlatesObj)=>{
    var predictedPlateNumbers=predictedPlatesObj["plateNumber"]
    if(predictedPlateNumbers.length==0){
        return null;
    }
    var existingPlateNumbers=[];
    return model.getNumberPlates().then((plateNumbers)=>{
        for(let i=0;i<plateNumbers.length;i++){
            existingPlateNumbers.push(plateNumbers[i]["licensePlateNumber"])
        }
        var d=[]
        for(let i=0;i<predictedPlateNumbers.length;i++){
            let n=predictedPlateNumbers[i];
            //console.log(n)
            let result=[]
            for(let j=0;j<existingPlateNumbers.length;j++){
                //console.log(existingPlateNumbers[j])
                result.push(lprsService.longestCommonSubsequence(existingPlateNumbers[j],n))
            }
            var max=result[0]
            var index=0;
            for(let k=1;k<result.length;k++){
                if(result[k]>max){
                    max=result[k]
                    index=k
                }
            }
            if(max<=4){
                return {"licensePlateNumber":n}
            }else{
                d.push(existingPlateNumbers[index]);
            }
            

        }
        console.log(d[0]);
        return model.getDetails(d[0]
        ).then((obj)=>{
            if(obj!=null){
                return obj;
            }else{
                let err = new Error("license plate not found");
                err.status=500
                throw err;
            }
        })
        
    })
}


lprsService.longestCommonSubsequence=(m,n)=>{
    var L = []
    for(let i=0;i<=m.length;i++){
        let result=[]
        for(let j=0;j<=n.length;j++){
            result.push(0);

        }
        L.push(result);
    }
    
    for (let i=0; i<=m.length; i++) 
    { 
      for (let j=0; j<=m.length; j++) 
      { 
        if (i == 0 || j == 0) 
            L[i][j] = 0; 
        else if (m[i-1] == n[j-1]) 
            L[i][j] = L[i-1][j-1] + 1; 
        else
            L[i][j] = max(L[i-1][j], L[i][j-1]); 
      } 
    } 
    
  return L[m.length][n.length];
}
var max=(x,y)=>x>y?x:y;

module.exports = lprsService;