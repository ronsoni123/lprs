var collection = require("../utilities/connections");
var lprsDb = {};

lprsDb.generateId = () => {
  return collection.getSignup().then(function(collection) {
    return collection.distinct("customerId").then(custId => {
      var max_cust_Id = Math.max(...custId);
      if (max_cust_Id > 0) return max_cust_Id + 1;
      else return 1001;
    });
  });
};

lprsDb.checkEmail = (email) => {
    return collection.getSignup().then((model) => {
        return model.findOne({email: email}).then((obj) => {          
            if(obj==null) {
                return true;
            }   
            else {
                return false;
            }
        })
    })
}

lprsDb.signupUser = userObj => {
  return collection.getSignup().then(model => {
    return lprsDb.generateId().then(custId => {
      userObj.customerId = custId;
      return lprsDb.checkEmail(userObj.email).then(response=>{          
          if(response){
            return model.insertMany(userObj).then(updated => {
                if (updated) {
                  return userObj;
                } 
                else {
                  return null;
                }
              });
          }
          else{
            let err = new Error("Email already used");
            err.status = 406;
            throw err;
          }
      })
    });
  });
};

lprsDb.editUser = userObj => {
  return collection.getSignup().then(model => {
      return model.findOne({email:userObj.email},{"_id":0}).then(response=>{          
          if(response){
            return model.updateOne({email:userObj.email},{
              $set :
              {
                firstName: userObj.firstName,
                lastName: userObj.lastName,
                email: userObj.email,
                password: userObj.password,
              }
            }).then(updated => {
                if (updated.nModified>0) {
                  return userObj;
                } 
                else {
                  return null;
                }
              });
          }
          else{
            let err = new Error("Email already used");
            err.status = 406;
            throw err;
          }
      })
    
  });
};


lprsDb.login= (loginObj)=>{
  return collection.getSignup().then(model=>{
    return model.findOne({email:loginObj.email}).then(obj=>{
      if(obj){
        if(loginObj.password===obj.password){
          return obj;
        }
        else{
          return null;
        }
      }
    })
  })

}
lprsDb.getNumberPlates=()=>{
  return collection.getDrivingDatabase().then(model=>{
    return model.find({},{"_id":0,"licensePlateNumber":true}).then((response)=>{
          if(response){
            //console.log("in model get number plates",response);
            return response;
          }else{
            return null;
          }
    })
  })
}

lprsDb.getDetails=(licensePlateNumber)=>{
  return collection.getDrivingDatabase().then(model=>{
    return model.findOne({"licensePlateNumber":licensePlateNumber},{"_id":0}).then((response)=>{
      if(response){
        return response;
      }else{
        return null;
      }
    })
  })
}
module.exports = lprsDb;
