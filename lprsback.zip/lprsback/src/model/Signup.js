class Signup {
    constructor(obj) {
        this.customerId = obj.customerId;
        this.firstName = obj.firstName;
        this.lastName = obj.lastName;
        this.email = obj.email;
        this.password = obj.password;
    }
}

module.exports=Signup;